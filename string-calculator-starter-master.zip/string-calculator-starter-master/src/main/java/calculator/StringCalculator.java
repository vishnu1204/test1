package calculator;

class StringCalculator {

    public int add(String input) {
        return 0;
    }

}